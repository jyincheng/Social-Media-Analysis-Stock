import json
import boto3
import pytrends
from pytrends.request import TrendReq
import pymysql
import sys
import datetime

endpoint = "cloudcomputingdb.cjzmmanfltlb.us-east-1.rds.amazonaws.com"
username = "admin"
passWord = "cloudcomputingteam14"
# database_name = "reddit"

# connection = pymysql.connect(host=endpoint, user=username, password=passWord, db=database_name)

def set_response(code, body):
    return {
        'statusCode': code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT',
            'Access-Control-Allow-Headers': 'Content-Type'
        },
        'body': json.dumps(body)
    }


def googlePop(query_text, time_interval):
    try:
        query_text_list = [query_text]
        
        # connect to Google Search API
        pytrend = TrendReq()
        pytrend.build_payload(query_text_list, cat=0, timeframe=time_interval, geo='', gprop='')  # first param is a list
        # get date, value from Google
        preload = pytrend.interest_over_time()
        print("Google Search: data retreive success")
    except Exception as e :
        print(e)

    preload_cleaned = preload.drop(columns=["isPartial"])
    print("preload_cleaned = ", preload_cleaned)

    # transfer to json format
    preload_2_json = json.loads(preload_cleaned.to_json(orient='table'))['data']
    print("preload_2_json = ", preload_2_json)

    # modify format of "date"
    for data in preload_2_json:
        for key, value in data.items():
            if key == "date":
                data[key] = value[0:10]
        data['value'] = data.pop(query_text)
        print("data['value'] = ", data['value'])

    # another way to write this loop:
    # for data in preload_2_json:
    #     data["date"] = data["date"][0:10]

    return preload_2_json


def senEmo(query_text, query_time, query_unit, platform):
    database_name = platform

    connection = pymysql.connect(host=endpoint, user=username, password=passWord, db=database_name)

    cursor = connection.cursor() #connect database
    print("RDB connected")

    listSenEmo = ['sentimentScore_Positive', 'sentimentScore_Negative', 'sentimentScore_Neutral', 
                        'sentimentScore_Mixed', 'emotion_Happy', 'emotion_Angry', 'emotion_Surprise', 
                        'emotion_Sad', 'emotion_Fear']
    keyWord = query_text

    list_tmp = []
    list_put_all = []
    dict_tmp = {}

    latest_date = datetime.datetime.today().strftime('%Y-%m-%d')
    print('Today is: ')
    print(latest_date)
    check = False
    if query_unit == 'm':
        interval_days = int(query_time)*30
        start_time_tmp = datetime.datetime.today() - datetime.timedelta(days=interval_days)
        start_time = start_time_tmp.strftime("%Y-%m-%d")
        print("Print %s month ago date: " %(query_time))
        print(start_time)
    elif query_unit == 'y':
        if platform == 'reddit':
            check = True
        else:
            check = False
        interval_days = int(query_time)*365
        start_time_tmp = datetime.datetime.today() - datetime.timedelta(days=interval_days)
        start_time = start_time_tmp.strftime("%Y-%m-%d")
        print("Print %s years ago date: " % (query_time))
        print(start_time)

    for i in range(9): #iterate all sentiment and emotion
        if check:
            sqlStr = "select DATE_FORMAT(post_time, '%Y-%m'), avg(" + listSenEmo[i] + ") from " + platform + " where keyword = '" + keyWord + "' and post_time between '" + start_time + "' and '"+ latest_date + "' GROUP BY YEAR(post_time), MONTH(post_time) ORDER BY post_time ASC"
        else:
            sqlStr = "select DATE(post_time), avg(" + listSenEmo[i] + ") from " + platform + " where keyword = '" + keyWord + "' and post_time between '" + start_time + "' and '"+ latest_date + "' GROUP BY YEAR(post_time), MONTH(post_time), DATE(post_time) ORDER BY post_time ASC"

        cursor.execute(sqlStr)
        rows = cursor.fetchall()
        print(rows)
        row_length = len(rows)

        list_mv_start = []
        list_mv_end = []
        list_mv_value_plus7 = []
        list_mv_value_avg = []
        
        list_date = []
        #put dates in the list
        for j in range(row_length):
            if check:
                list_date.append(rows[j][0])
            else:
                list_date.append(rows[j][0].strftime("%Y-%m-%d"))
        
        #put 4 month value in the list_mv_value
        if check:
            print(row_length)
            if row_length < 7:
                p = row_length
            else:
                p = 7
            for j in range(p):
                end = datetime.datetime.strptime(rows[j][0], '%Y-%m')
                start = end - datetime.timedelta(days=120)
                start_str = start.strftime("%Y-%m")
                end_str = end.strftime("%Y-%m")
                sql_command = "select avg(" + listSenEmo[i] + ") from " + platform + " where keyword = '" + keyWord + "' and post_time between '" + start_str + "-01' and '" + end_str + "-01'"
                cursor.execute(sql_command)
                rows_i = cursor.fetchall()
                if rows_i[0][0] is None:
                    list_mv_value_plus7.append(0.0)
                else:
                    list_mv_value_plus7.append(rows_i[0][0])
            
            j = 0
            while p < 7:
                end = datetime.datetime.strptime(rows[j][0], '%Y-%m')
                start = end - datetime.timedelta(days=120)
                start_str = start.strftime("%Y-%m")
                end_str = end.strftime("%Y-%m")
                sql_command = "select avg(" + listSenEmo[i] + ") from " + platform + " where keyword = '" + keyWord + "' and post_time between '" + start_str + "-01' and '" + end_str + "-01'"
                cursor.execute(sql_command)
                rows_i = cursor.fetchall()
                if rows_i[0][0] is None:
                    list_mv_value_plus7.append(0.0)
                else:
                    list_mv_value_plus7.append(rows_i[0][0])

                p+=1
                    
                    
        #put 7 days value in the list_mv_value        
        else:
            print(row_length)
            if row_length < 7:
                p = row_length
            else:
                p = 7
            for j in range(p):
                end = rows[j][0] # end time
                start = end - datetime.timedelta(days=7)
                star_time = start.strftime("%Y-%m-%d")
                end_time = end.strftime("%Y-%m-%d")
                sql_command = "select avg(" + listSenEmo[i] + ") from " + platform + " where keyword = '" + keyWord + "' and post_time between '" + star_time + "' and '" + end_time + "'"
                cursor.execute(sql_command)
                rows_i = cursor.fetchall()
                list_mv_value_plus7.append(rows_i[0][0])
            j = 0
            while p < 7:
                end = rows[j][0] # end time
                start = end - datetime.timedelta(days=7)
                star_time = start.strftime("%Y-%m-%d")
                end_time = end.strftime("%Y-%m-%d")
                sql_command = "select avg(" + listSenEmo[i] + ") from " + platform + " where keyword = '" + keyWord + "' and post_time between '" + star_time + "' and '" + end_time + "'"
                cursor.execute(sql_command)
                rows_i = cursor.fetchall()
                list_mv_value_plus7.append(rows_i[0][0])
                #j+=1
                p+=1
                
        
        # put in value1
        list_value1 = []
        for j in range(row_length): #iterate all rows
            if check:
                list_value1.append(rows[j][1])
                list_mv_value_plus7.append(rows[j][1])
            else:
                list_value1.append(rows[j][1])
                list_mv_value_plus7.append(rows[j][1])
            
 
        list_value2 = []
        if check:
            k = 0 # k start from day 1
            l = 4 # l start from month 4
            total = 0
        
            for j in range(len(list_value1)): 
                for m in range(k, l+1):
                    if list_mv_value_plus7[m] is None:
                        list_mv_value_plus7[m] = 0.0
                    total += list_mv_value_plus7[m]
                list_value2.append(total/4.0)
                total = 0
                k+=1
                l+=1
        
            for i in range(len(list_value1)):
                dict_tmp['date'] = list_date[i]
                dict_tmp['value1'] = list_value1[i]
                dict_tmp['value2'] = list_value2[i]
        
                dict_copy = dict_tmp.copy()
                #print(dict_copy)
                list_tmp.append(dict_copy)
        else:
            k = 0 # k start from day 1
            l = 6 # l start from day 7
            total = 0
        
            for j in range(len(list_value1)): 
                for m in range(k, l+1):
                    if list_mv_value_plus7[m] is None:
                        list_mv_value_plus7[m] = 0.0
                    total += list_mv_value_plus7[m]
                list_value2.append(total/7.0)
                total = 0
                k+=1
                l+=1
        
            for i in range(len(list_value1)):
                dict_tmp['date'] = list_date[i]
                dict_tmp['value1'] = list_value1[i]
                dict_tmp['value2'] = list_value2[i]
        
                dict_copy = dict_tmp.copy()
                print(dict_copy)
                list_tmp.append(dict_copy)
            
        print('change sentiment and emotion')

        list_put_all.append(list_tmp.copy())

        list_tmp.clear()
        dict_tmp.clear()

    print(list_put_all)
    return list_put_all



def lambda_handler(event, context):
    # print('####START####')
    search = event['queryStringParameters']
    if not search:
        return set_response(400, "Bad request, there was nothing in the query params")
    query_text = search['q'].lower()  # query_text is string
    query_time = search['time']
    query_unit = search['unit']
    print(f'{query_text} {query_time} {query_unit}')
    
    # convert time
    one_day = datetime.timedelta(days=1)
    end_date = datetime.date.today()
    if query_unit == 'm':
        start_date = end_date - one_day * 30 * int(query_time)
    else:
        start_date = end_date - one_day * 365 * int(query_time)
    time_interval = start_date.strftime("%Y-%m-%d") + ' ' + end_date.strftime("%Y-%m-%d")

    graphList = []
    
    # insert data from googlePop
    graphList.append(googlePop(query_text, time_interval))
    if len(graphList[0]) == 0:
        return set_response(444, "Error from Google Search: too many search request, please try later")
    print(graphList)
    print("Google Search Popularity Completed")

    # insert data from senEno
    graphList.extend(senEmo(query_text, query_time, query_unit, "reddit"))
    graphList.extend(senEmo(query_text, query_time, query_unit, "twitter"))

    return set_response(200, graphList)