import pymysql
import json
import sys

endpoint = "cloudcomputingdb.cjzmmanfltlb.us-east-1.rds.amazonaws.com"
username = "admin"
passWord = "cloudcomputingteam14"
database_name = "reddit"

connection = pymysql.connect(host=endpoint, user=username, password=passWord, db=database_name)

def generateListDate(year, month):#generate dates in a month
    listDate = []
    list31 = ['01', '03', '05', '07', '08', '10', '12']
    for i in range(1,10):
            strDate = year + '-' + month + '-0' + str(i)
            listDate.append(strDate)
    for i in range(10, 29):
            strDate = year + '-' + month + '-' + str(i)
            listDate.append(strDate)
    
    if year == '2021'and month == '02':
        return listDate
    
    elif year == '2020'and month == '02':
        listDate.append('2020-02-29')
        return listDate
    
    elif month in list31:
        for i in range(29, 32):
            strDate = year + '-' + month + '-' + str(i)
            listDate.append(strDate)
        return listDate
    else:
        for i in range(29, 31):
            strDate = year + '-' + month + '-' + str(i)
            listDate.append(strDate)
        return listDate

def set_response(code, body):
    return {
        'statusCode': code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT',
            'Access-Control-Allow-Headers': 'Content-Type'
        },
        'body': json.dumps(body)
    }

def lambda_handler(event, context):
    
    search = event['queryStringParameters']
    
    if not search:
        return set_response(400, "Bad request, there was nothing in the query params")
    query_text = search['q']  # query_text is string

    cursor = connection.cursor() #connect database

    listSenEmo = ['sentimentScore_Positive', 'sentimentScore_Negative', 'sentimentScore_Neutral', 
                        'sentimentScore_Mixed', 'emotion_Happy', 'emotion_Angry', 'emotion_Surprise', 
                        'emotion_Sad', 'emotion_Fear']
    keyWord = query_text

    list_tmp = []
    list_put_all = []
    dict_tmp = {}

    year = '2021' #input from user
    month = '01' #input from user

    for i in range(9): #iterate all sentiment and emotion
        listDate = generateListDate(year, month)
        for j in range(len(listDate) - 1): #iterate all datetime
            sqlStr = "select avg(" + listSenEmo[i] + ") from reddit where keyword = '" + keyWord + "' and post_time between '" + listDate[j] + "' and '" + listDate[j+1] + "'"
            cursor.execute(sqlStr)
            rows = cursor.fetchall()
            dict_tmp['date'] = listDate[j]
            dict_tmp['value'] = rows[0][0]
            dict_copy = dict_tmp.copy()
            list_tmp.append(dict_copy)
        list_put_all.append(list_tmp.copy())

        list_tmp.clear()
        dict_tmp.clear()
    
    print(list_put_all)
    preload_2_json = json.dumps(list_put_all)
    print(preload_2_json)
    return set_response(200, preload_2_json)
