import json
import boto3
import pymysql
import datetime

endpoint = "cloudcomputingdb.cjzmmanfltlb.us-east-1.rds.amazonaws.com"
username = "admin"
passWord = "cloudcomputingteam14"
database_name = "event"

connection = pymysql.connect(host=endpoint, user=username, password=passWord, db=database_name)

def set_response(body):
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT',
            'Access-Control-Allow-Headers': 'Content-Type'
        },
        'body': json.dumps(body)
    }


def lambda_handler(event, context):
    print(event)
    data = json.loads(event['body'])

    x = datetime.datetime.now()
    
    date = x.strftime("%Y-%m-%d %H:%M:%S")
    keyword = data["keyword"]
    email = data["email"]
    print(data["popularity"])
    popularity = "{:.2f}".format(float(data["popularity"])/100.00)
    positive = "{:.2f}".format(float(data["positive"])/100.00)
    # positive = 0.5
    negative = "{:.2f}".format(float(data["negative"])/100.00)
    neutral = "{:.2f}".format(float(data["neutral"])/100.00)
    mixed = "{:.2f}".format(float(data["mixed"])/100.00)
    happy = "{:.2f}".format(float(data["happy"])/100.00)
    angry = "{:.2f}".format(float(data["angry"])/100.00)
    surprise = "{:.2f}".format(float(data["surprise"])/100.00)
    sad = "{:.2f}".format(float(data["sad"])/100.00)
    fear = "{:.2f}".format(float(data["fear"])/100.00)


    cur = connection.cursor()
    sql = """insert into event_table (date, keyword, email, popularity, positive, negative, neutral, mixed, happy, angry, surprise,
                                  sad, fear) values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
    cur.execute(sql,(date, keyword, email, popularity, positive, negative, neutral, mixed, happy, angry, surprise, sad, fear))
    connection.commit()

    return set_response("OK")
    




